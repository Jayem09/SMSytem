package main

import (
	"log"
	"smsystem-backend/internal/config"
	"smsystem-backend/internal/database"
)

func main() {
	cfg := config.Load()
	database.Connect(cfg)

	log.Println("Manually altering orders table to allow NULL customer_id...")

	// Use raw DB to execute these outside of a failing transaction block
	database.DB.Exec("ALTER TABLE orders DROP FOREIGN KEY fk_orders_customer")

	err := database.DB.Exec("ALTER TABLE orders MODIFY customer_id INT UNSIGNED NULL").Error
	if err != nil {
		log.Fatalf("Modification failed: %v", err)
	}
	log.Println("Column 'customer_id' is now nullable.")

	err = database.DB.Exec("ALTER TABLE orders ADD CONSTRAINT fk_orders_customer FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE SET NULL").Error
	if err != nil {
		log.Printf("Warning: Re-adding FK failed: %v", err)
		log.Println("However, the column is now NULLABLE, which should fix the walk-in issue.")
	} else {
		log.Println("FK recreated successfully with ON DELETE SET NULL.")
	}
}
